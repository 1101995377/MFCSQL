//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by databaseGUY.rc
//
#define IDR_CNTR_INPLACE                6
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_DATABASEGUY_FORM            101
#define IDP_FAILED_TO_CREATE            102
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_MAINFRAME                   128
#define IDR_DATABATYPE                  129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDD_DIALOG3                     132
#define IDC_ADD                         1000
#define IDC_DEL                         1001
#define IDC_MOD                         1002
#define IDC_NAME_EDIT                   1003
#define IDC_ID_EDIT                     1004
#define IDC_CHECKNAME                   1005
#define IDC_AGE_EDIT                    1006
#define IDC_DEPT_EDIT                   1007
#define IDC_CHECK                       1008
#define IDC_BUTTON5                     1009
#define IDC_BUTTON6                     1010
#define IDC_BUTTON7                     1011
#define IDC_BUTTON8                     1012
#define IDC_BUTTON9                     1013
#define IDC_BUTTON10                    1014
#define IDC_query_EDIT                  1015
#define IDC_SQL_EDIT                    1016
#define IDC_AGE                         1017
#define IDC_ADD2                        1017
#define IDC_ID                          1018
#define IDC_DEL2                        1018
#define IDC_DEPT                        1019
#define IDC_MOD2                        1019
#define IDC_NAME                        1020
#define IDC_CNO_EDIT2                   1020
#define IDC_ID_EDIT2                    1021
#define IDC_CNO                         1022
#define IDC_CHECKNAME3                  1022
#define IDC_LIST1                       1023
#define IDC_CNAME                       1023
#define IDC_TEACHER                     1024
#define IDC_GRADE_EDIT2                 1024
#define IDC_CHECKNAME2                  1025
#define IDC_CHECK2                      1026
#define IDC_SNO1                        1033
#define IDC_CNO1                        1034
#define IDC_GRADE1                      1035
#define ID_CANCEL_EDIT_CNTR             32768

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
